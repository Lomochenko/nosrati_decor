"""
URL configuration for nosrati project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import path, include

from Blog.sitemap import BlogSitemap
from Product.sitemap import CategorySitemap, ProductViewSitemap
from sitemaps.sitemaps import StaticViewSitemap

sitemaps = {
    "static": StaticViewSitemap,
    "blog": BlogSitemap,
    'categories': CategorySitemap,
    'product-view': ProductViewSitemap,
}

handler404 = '404.views.error_404'
handler500 = '404.views.custom_500_view'

urlpatterns = [
                  path('admin/', admin.site.urls),
                  path('', include('Home.urls')),
                  path('', include('Product.urls')),
                  path('', include('Blog.urls')),
                  path('', include('robots.urls')),
                  path(
                      "sitemap.xml",
                      sitemap,
                      {"sitemaps": sitemaps},
                      name="django.contrib.sitemaps.views.sitemap",
                  ),
                  path('summernote/', include('django_summernote.urls')),
              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

admin.site.site_title = "داشبورد"
admin.site.index_title = "dashboard"
admin.site.site_header = "کابینت نصرتی"
